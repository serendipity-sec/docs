# 민우 담당 조사 — Skill × MCP 결합 보안

작성·원문 확인: **2026-09-25** · 담당: 김민우 · AI 보조 조사/실행 기록 포함

> **심층 조사 후 결론:** 결합 탐지뿐 아니라 **작업 의도·출처·권한을 함께 검사하는 방법도 IntentCap·SkillGuard·Fides 등에 존재한다.** 제안은 불완전한 Skill/MCP 설정에서 필요한 근거를 복원하고, 같은 정책 엔진·같은 입력 조건으로 기존 방법과 비교하는 방향으로 좁혔다. 새 보안 원리나 성능 우월성은 아직 입증하지 않았다.

## 먼저 읽을 것

| 시간 | 문서 | 얻어갈 것 |
|---|---|---|
| **10분** | **[교수 면담용 선행연구 논증](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/09-%EA%B5%90%EC%88%98%EB%A9%B4%EB%8B%B4%EC%9A%A9-%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC-%EB%85%BC%EC%A6%9D.md)** | **가장 가까운 연구와 차이, 철회한 주장, 검증·기각 조건** |
| 25분 | [심층 웹 조사·선행연구 재검증](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/08-%EC%8B%AC%EC%B8%B5%EC%9B%B9%EC%A1%B0%EC%82%AC%EC%99%80-%EC%84%A0%ED%96%89%EC%97%B0%EA%B5%AC-%EC%9E%AC%EA%B2%80%EC%A6%9D.md) | 추가 16편, 코드·표준, IntentCap 부분 실행 |
| 5분 | [회의 설명문·예상 질문](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/06-%ED%9A%8C%EC%9D%98%EC%A4%80%EB%B9%84.md) | 자료를 읽어주지 않고 설명할 핵심 |
| 15분 | [개념·위협 모델·사례](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/01-%EA%B0%9C%EB%85%90%EA%B3%BC-%EC%82%AC%EB%A1%80.md) | 무엇이 진짜 결합 문제인지 |
| 20분 | [논문 비교](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/02-%EB%85%BC%EB%AC%B8-%EB%B9%84%EA%B5%90.md) | 기존 탐지 원리와 반론 |
| 15분 | [도구 내부 분석](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/03-%EB%8F%84%EA%B5%AC-%EB%82%B4%EB%B6%80%EB%B6%84%EC%84%9D.md) | README를 넘어 확인한 코드 경로 |
| 15분 | [Research Gap·아키텍처·평가](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/04-Gap%EA%B3%BC-%EC%95%84%ED%82%A4%ED%85%8D%EC%B2%98.md) | 무엇을 만들고 어떻게 반증할지 |
| 10분 | [직접 실행 결과](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/05-%EC%8B%A4%ED%97%98%EA%B3%BC-%EC%9E%AC%ED%98%84.md) | 관측 사실과 아직 못 증명한 것 |
| 참고 | [출처·조사 범위](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/07-%EC%B6%9C%EC%B2%98%EC%99%80-%EC%A1%B0%EC%82%AC%EA%B8%B0%EB%A1%9D.md) | 출처 ID, 확인 수준, 제외한 주장 |

## 이번에 확보한 근거

- **논문·학술 연구 28편**을 확인 범위와 함께 정리했다. 최초 12편에 IntentCap·SkillGuard·Fides·PCAS 등 16편을 추가했다. **28편 전체 정독·재현을 뜻하지 않는다.** 추가 웹 검색 48개와 출처 추적·제외 사유를 [기록](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/evidence/deep-web-research.json)했다.
- 최초 5개에 **공개 구현/평가 저장소 5개와 공식 확장 명세 저장소**를 추가 확인했다. code path·commit·읽은 범위를 구분했다. SkillGuard의 hook은 미확보 gitlink 아래여서 구현 검증에서 제외했다.
- Cisco 검사기 2종, CompoSkill의 **그래프 함수**, IntentCap의 **정책 checker**를 제한적으로 실행했다. IntentCap은 합성 4조건·5이벤트가 예상대로 판정됐다. 이는 기존 기능 확인이며 보안 성능 재현이 아니다. [실행 근거](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/evidence/intentcap-checker-results.json)
- Cisco Skill Scanner **2.1.0**은 `private` 읽기 Skill과 `webhook` 발행 Skill을 함께 검사할 때 `CROSS_SKILL_DATA_RELAY`를 보고했다. 두 Skill 각각의 finding은 0개였다. **기존 도구가 결합 위험을 전혀 못 본다는 주장은 틀린다.** [실행 근거](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/evidence/skill-scanner-results.json)
- MCP 도구 이름으로 기술한 읽기/발행 Skill 쌍과 단일 보고 Skill에서는 같은 오프라인 모드가 finding을 보고하지 않았다. **실제 침해를 재현한 결과가 아니라, 입력 표현과 분석 범위에 따른 차이**다.
- Cisco MCP Scanner **4.8.4**의 YARA 모드에서 일반 도구 2개는 무경고였다. 무해한 지시 덮어쓰기 문장도 표현에 따라 탐지 결과가 달랐다. LLM·API 분석기까지 실패했다고 확대 해석하면 안 된다. [실행 근거](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/evidence/mcp-scanner-results.json)

## 회의에서 제안할 범위

**우선 탐지 대상:** 비공개 자료를 읽고 요약·가공한 뒤 허용되지 않은 공개 대상에 보내는 경로. 읽기나 발행 기능 자체보다 **자료의 등급, 전달 경로, 대상의 접근 범위, 사용자 승인**의 조합을 검사한다.

**첫 구현:** 제공된 정적 자료 → 연결·권한 근거 복원 → 명시적 계약과 모순/누락 검사 → 고정된 기존 정책 엔진과 비교 → 위험 후보/통제에 막힌 경로/근거 부족 표시. 근거 추출 성능과 정책 검사 성능을 나눈다. 공식 Skills over MCP의 서버별 식별·manifest·승인 수명은 기본 요건으로 반영한다.

**차별성 검증 기준:** IntentCap·SkillGuard·Fides/PCAS의 가정을 검토하고, harness-eval·skil·Cisco 교차 검사·TFA와 적용 범위를 맞춰 비교한다. **기존 방법에도 같은 근거를 제공했을 때 이득이 유지되는가**가 핵심이다. 성능 차이가 사라지면 새 탐지법 주장을 접고 근거 복원·배포 감사 또는 비교 실증 기여로 제한한다.

## 제출·인계 메모

이번 요청의 일정을 기준으로 자료 제출은 **9월 25일 금요일 23:59**, 회의는 **9월 26일 토요일 22:00, 한국시간**으로 이해했다. 기존 저장소 README의 팀장·회의시간 표와 다른 새 공지는 이 조사 문서에만 적용했다.

로컬에 별도의 **지식 지도 설계 명세**는 발견하지 못했다. 기존 `프로젝트지도.html`은 설명 자료이므로 그것을 데이터 스키마로 간주하지 않았다. 출처 → 주장 → 공백 → 아키텍처의 연결은 [임시 지식 지도 JSON](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/research/2026-09-25-Skill-MCP-%EA%B2%B0%ED%95%A9%EB%B3%B4%EC%95%88/evidence/knowledge-map.json)에 보존했다. 팀 명세를 받으면 필드만 변환할 수 있다.

[Notion 가져오기용 ZIP](https://github.com/serendipity-sec/docs/blob/docs/3-skill-mcp-research/notion/skill-mcp-2026-09-25-import.zip)은 이 폴더의 Markdown 10개를 담았다. ZIP 안의 증거·코드 링크는 GitHub 제출 브랜치로 연결된다. Notion 연결이 없어 실제 페이지 업로드는 하지 않았다. 팀의 지식 지도/Notion 구조를 받으면 그 구조에 맞춰 옮길 수 있다.
